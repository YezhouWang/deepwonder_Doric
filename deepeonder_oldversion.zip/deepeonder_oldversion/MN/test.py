def Joint_Mask_List_Simple1(final_mask_list_ct, now_mask_list_ct, corr_mark):
    for ii in range(0, len(now_mask_list_ct)):
        now_neuron = now_mask_list_ct[ii]
        now_neuron_trace = now_neuron['trace']
        now_neuron_position = now_neuron['position']
        now_neuron_centroid = now_neuron['centroid']
        # print(' ii -----> ',str(ii))
        if_coor_neuron = 0
        coor_patch_list = []
        if_close_neuron = 0
        posi_patch_list = []
        max_pccs = 0
        for iii in range(0, len(final_mask_list_ct)):
            old_neuron = final_mask_list_ct[iii]
            old_neuron_trace = old_neuron['trace']
            # print('old_neuron_trace -----> ',old_neuron_trace.shape)
            old_neuron_position = old_neuron['position']
            old_neuron_centroid = old_neuron['centroid']

            distance = centroid_distance(old_neuron_centroid, now_neuron_centroid)
            if distance<20:
                if_close_neuron = 1
                pccs1 = cal_pccs(old_neuron_trace, now_neuron_trace, now_neuron_trace.shape[0])
                # print('pccs1 ----- ',pccs1)
                if pccs1>corr_mark:
                    if_coor_neuron = 1
                    coor_patch_list.append(iii)
                    # print('coor_patch_list -----> ',len(coor_patch_list))
                list_inter_len = len(list_inter(now_neuron_position, old_neuron_position))
                now_neuron_position_len = len(now_neuron_position)
                old_neuron_position_len = len(old_neuron_position)
                if (list_inter_len/old_neuron_position_len)>0.8 or (list_inter_len/now_neuron_position_len)>0.8:
                    if_coor_neuron = 1
                    coor_patch_list.append(iii)

        if if_coor_neuron ==0:
            # print('Add Neuron =====> ',i,' ==> ',ii,' ==> ',Add_num)
            new_single_neuron = {}
            new_single_neuron['position'] = now_neuron_position
            new_single_neuron['trace'] = now_neuron_trace
            new_single_neuron['centroid'] = now_neuron_centroid
            final_mask_list_ct.append(new_single_neuron)

        if (if_close_neuron==1)&(if_coor_neuron==1):
            # print('Merge Neuron =====> ',i,' ==> ',ii)
            same_patch_index = coor_patch_list[0]
            same_patch = final_mask_list_ct[same_patch_index]
            same_patch_position = same_patch['position']
            # print('same_patch_position -----> ',len(same_patch_position))
            same_patch_position = list_union(same_patch_position, now_neuron_position) #list(set(same_patch_position)|set(now_patch_position))
            # print('same_patch_position -----> ',len(same_patch_position))
            # print('same_patch[centroid] -----> ',same_patch['centroid'])
            same_patch['position'] = same_patch_position
            final_mask_list_ct[same_patch_index] = same_patch
    return final_mask_list_ct


'''
def joint_neuron1(whole_mask_list, sub_mask_list, init_h, init_w):
    corr_mark = 0.8
    if len(whole_mask_list)>1:
        list_len = len(sub_mask_list)
        end_mark = whole_mask_list[-1]['value']
        for i in range(0, len(sub_mask_list)):
            now_patch = sub_mask_list[i]
            now_patch_trace = now_patch['trace']
            now_patch_position = now_patch['position']

            if_coor_patch = 0
            for ii in range(0, len(whole_mask_list)):
                old_patch = whole_mask_list[ii]

                old_patch_trace = old_patch['trace']
                pccs1 = cal_pccs(old_patch_trace, now_patch_trace, now_patch_trace.shape[0])
                if pccs1>corr_mark:
                    # print('Coor Neuron =====> ',i,' ==> ',ii,' ==> ',iii)
                    if_coor_patch = 1
                    # coor_patch_list.append(iii)

            if if_coor_patch==0:
                # print('Add Neuron =====> ',i,' ==> ',ii,' ==> ',Add_num)
                new_single_seg = {}
                new_single_seg['value'] = end_mark+1
                end_mark = end_mark+1
                now_patch_position = correct_position(now_patch_position, init_h, init_w)
                new_single_seg['position'] = now_patch_position
                new_single_seg['trace'] = now_patch_trace
                whole_mask_list.append(new_single_seg)
    if len(whole_mask_list)<1:
        for i in range(0, len(sub_mask_list)):
            now_patch = sub_mask_list[i]
            now_patch_trace = now_patch['trace']
            now_patch_position = now_patch['position']

            new_single_seg = {}
            new_single_seg['value'] = i+1

            now_patch_position = correct_position(now_patch_position, init_h, init_w)
            new_single_seg['position'] = now_patch_position
            new_single_seg['trace'] = now_patch_trace
            whole_mask_list.append(new_single_seg)
    return whole_mask_list
'''
'''
def Split_Neuron(single_neuron, image):
    position = single_neuron['position']
    len_p = len(position)
    mask_matrix = np.zeros((image.shape[0], len_p))
    for i in range(0, len_p):
        mask_matrix[:,i] = image[:, position[i][0], position[i][1]]
    
    mask_matrix = mask_matrix.T
    nmf_dim = 20
    nmf_model = NMF(n_components=nmf_dim, init='random', random_state=0)
    W = nmf_model.fit_transform(mask_matrix)

    # kmeans_num = 5
    neuron_size = 300
    kmeans_num = round(len(position)/neuron_size)
    kmeans_model = KMeans(n_clusters=kmeans_num)
    kmeans_model.fit(W)
    label_pred = kmeans_model.labels_
    
    neuron_list = []
    for i in range(0, kmeans_num):
        selected_list = np.argwhere(label_pred == i)

        new_single_neuron={}
        new_single_neuron['position'] = []
        for ii in range(0, len(selected_list)):
            # print(selected_list[ii])
            selected_index = selected_list[ii][0]
            new_single_neuron['position'].append(position[selected_index])
        
        neuron_list.append(new_single_neuron)
    return neuron_list
'''

now_neuron_position --->  237
now_neuron_position --->  405
now_neuron_position --->  353
now_neuron_position --->  307
now_neuron_position --->  228
now_neuron_position --->  148
now_neuron_position --->  304
now_neuron_position --->  306
now_neuron_position --->  497
now_neuron_position --->  278
now_neuron_position --->  448
now_neuron_position --->  417
now_neuron_position --->  234
now_neuron_position --->  440
now_neuron_position --->  327
now_neuron_position --->  106
now_neuron_position --->  366
now_neuron_position --->  396
now_neuron_position --->  179
now_neuron_position --->  472
now_neuron_position --->  369
now_neuron_position --->  283
now_neuron_position --->  159
now_neuron_position --->  253
now_neuron_position --->  289
now_neuron_position --->  322
now_neuron_position --->  325
now_neuron_position --->  213
now_neuron_position --->  348
now_neuron_position --->  250
now_neuron_position --->  346
now_neuron_position --->  138
now_neuron_position --->  366
now_neuron_position --->  355
now_neuron_position --->  296
now_neuron_position --->  186
now_neuron_position --->  265
now_neuron_position --->  137
now_neuron_position --->  193
now_neuron_position --->  436
now_neuron_position --->  212
now_neuron_position --->  117
now_neuron_position --->  381
now_neuron_position --->  100
now_neuron_position --->  280
now_neuron_position --->  310
now_neuron_position --->  77
now_neuron_position --->  305
now_neuron_position --->  249
now_neuron_position --->  271
now_neuron_position --->  83
now_neuron_position --->  322
now_neuron_position --->  171
now_neuron_position --->  397
now_neuron_position --->  78
now_neuron_position --->  97
now_neuron_position --->  239
now_neuron_position --->  91
now_neuron_position --->  138
now_neuron_position --->  282
now_neuron_position --->  110
now_neuron_position --->  151
now_neuron_position --->  347
now_neuron_position --->  136
now_neuron_position --->  98
now_neuron_position --->  350
now_neuron_position --->  189
now_neuron_position --->  202
now_neuron_position --->  240
now_neuron_position --->  87
now_neuron_position --->  403
now_neuron_position --->  115
now_neuron_position --->  64
now_neuron_position --->  78
now_neuron_position --->  255
now_neuron_position --->  111
now_neuron_position --->  126



now_neuron_position --->  [[137, 227], [137, 228], [137, 229], [137, 230], [138, 225], 
[138, 226], [138, 227], [138, 228], [138, 229], [138, 230], [138, 231], [138, 232], 
[139, 224], [139, 225], [139, 226], [139, 227], [139, 228], [139, 229], [139, 230], 
[139, 231], [139, 232], [139, 233], [140, 224], [140, 225], [140, 226], [140, 227], 
[140, 228], [140, 229], [140, 230], [140, 231], [140, 232], [140, 233], [141, 224], 
[141, 225], [141, 226], [141, 227], [141, 228], [141, 229], [141, 230], [141, 231], 
[141, 232], [141, 233], [141, 234], [142, 224], [142, 225], [142, 226], [142, 227], 
[142, 228], [142, 229], [142, 230], [142, 231], [142, 232], [142, 233], [142, 234], 
[143, 224], [143, 225], [143, 226], [143, 227], [143, 228], [143, 229], [143, 230], 
[143, 231], [143, 232], [143, 233], [143, 234], [144, 224], [144, 225], [144, 226], 
[144, 227], [144, 228], [144, 229], [144, 230], [144, 231], [144, 232], [144, 233], 
[144, 234], [145, 225], [145, 226], [145, 227], [145, 228], [145, 229], [145, 230], 
[145, 231], [145, 232], [145, 233], [146, 226], [146, 227], [146, 228], [146, 229], 
[146, 230], [146, 231], [146, 232], [146, 233], [147, 228], [147, 229], [147, 230], [147, 231]]


single_neuron[] --->  1161
single_neuron[] --->  310
single_neuron[] --->  305
single_neuron[] --->  350
single_neuron[] --->  727
single_neuron[] --->  319
single_neuron[] --->  614
single_neuron[] --->  369
single_neuron[] --->  561
single_neuron[] --->  405
single_neuron[] --->  346
single_neuron[] --->  853
single_neuron[] --->  159
single_neuron[] --->  397
single_neuron[] --->  353
single_neuron[] --->  115
single_neuron[] --->  690
single_neuron[] --->  227
single_neuron[] --->  106
single_neuron[] --->  366
single_neuron[] --->  307
single_neuron[] --->  202
single_neuron[] --->  250
single_neuron[] --->  347
single_neuron[] --->  255
single_neuron[] --->  228
single_neuron[] --->  193
single_neuron[] --->  501
single_neuron[] --->  381
single_neuron[] --->  64
single_neuron[] --->  97
single_neuron[] --->  758
single_neuron[] --->  186
single_neuron[] --->  776
single_neuron[] --->  234
single_neuron[] --->  87
single_neuron[] --->  322
single_neuron[] --->  850
single_neuron[] --->  583
single_neuron[] --->  629
single_neuron[] --->  304
single_neuron[] --->  240
single_neuron[] --->  189
single_neuron[] --->  137
single_neuron[] --->  126
single_neuron[] --->  280
single_neuron[] --->  98
single_neuron[] --->  1006


def listAddtrace(list, image):
    for i in range(0, len(list)):
        single_seg = list[i]
        position = single_seg['position']
        if not 'trace' in single_seg or not 'centroid' in single_seg:
            trace = np.zeros((image.shape[0], ))
            centroid = np.zeros((2,))
            for ii in range(0, len(position)):
                now_position = position[ii]
                single_trace = image[:, now_position[0], now_position[1]].squeeze()
                trace = trace+image[:, now_position[0], now_position[1]].squeeze()
                centroid = now_position+centroid
            centroid = centroid/len(position)
            ave_trace = trace/len(position)
            single_seg['centroid'] = centroid
            single_seg['trace'] = ave_trace
    return list



def listAddtrace(list, image):
    # image: T H W
    new_list = []
    # print('listAddtrace len(list) -----> ',len(list))
    for i in range(0, len(list)):
        new_single_seg = {}
        single_seg = list[i]
        position = single_seg['position']
        # print('position -----> ',len(position))
        if len(position) != 0:
            trace = np.zeros((image.shape[0], ))
            # print('trace -----> ',trace.shape)
            centroid = np.zeros((2,))
            for ii in range(0, len(position)):
                # print('i -----> ',i,' ii -----> ',ii)
                now_position = position[ii]
                # print('now_position -----> ',now_position)
                # single_seg['position'].append(now_position)
                single_trace = image[:, now_position[0], now_position[1]].squeeze()
                trace = trace+image[:, now_position[0], now_position[1]].squeeze()
                # print('single_trace -----> ',single_trace.shape)
                centroid = now_position+centroid
            # #print('len(position) -----> ',len(position))
            centroid = centroid/len(position)
            ave_trace = trace/len(position)
            # print('centroid -----> ',centroid)
            if not 'split' in single_seg:
                new_single_seg['trace'] = ave_trace
                # print('------> no key ave_trace')
            if 'split' in single_seg:
                if single_seg['split'] == 0:
                    new_single_seg['trace'] = ave_trace
                    # print('------> ave_trace')
            if 'split' in single_seg:
                if single_seg['split'] == 1:
                    new_single_seg['trace'] = single_seg['trace']
                    # print('------> single_seg')

            if 'split' in single_seg:
                new_single_seg['split'] = single_seg['split']
            if not 'split' in single_seg:
                new_single_seg['split'] = 0

            if 'round_rate' in single_seg:
                new_single_seg['round_rate'] = single_seg['round_rate']
            new_single_seg['centroid'] = centroid
            new_single_seg['position'] = single_seg['position']
            new_list.append(new_single_seg)
    return new_list



def merge_neuron_SEG1(mask_stack, 
                    raw_image, 
                    quit_round_rate = 0.5, 
                    good_round_rate = 0.8,
                    good_round_size_rate = 0.4, 
                    corr_mark=0.9, 
                    max_value=1000):
    corr_mark = corr_mark

    quit_round_rate = quit_round_rate
    good_round_rate = good_round_rate
    good_round_size_rate = good_round_size_rate

    threshold = max_value*0.3
    mask_stack[mask_stack>threshold] = max_value
    mask_stack[mask_stack<threshold] = 0

    initial_mask = mask_stack[0,:,:].squeeze()

    initial_mask_list = Neuron_List_Initial(initial_mask, 
                                            raw_image,
                                            quit_round_rate, 
                                            good_round_rate, 
                                            good_round_size_rate)
    # print('initial_mask_list -----> ', len(initial_mask_list))
    initial_mask_list_ct = listAddtrace(initial_mask_list, raw_image)

    final_mask_list_ct = initial_mask_list_ct

    prev_time = time.time()
    time_start = time.time()
    ###############################################################################################
    for i in range(1, mask_stack.shape[0]):
        now_mask = mask_stack[i,:,:].squeeze()
        # print('i -----> ',i)
        # print_time(time_start)
        now_mask_list = Neuron_List_Initial(now_mask, 
                                            raw_image,
                                            quit_round_rate, 
                                            good_round_rate, 
                                            good_round_size_rate)
        # print('initial_mask_list -----> ', len(initial_mask_list))
        # print('centroid -----> ',sub_mask_list[0]['centroid'])
        # print_time(time_start)
        now_mask_list_ct = listAddtrace(now_mask_list, raw_image)
        # print('centroid -----> ',now_mask_list_ct[0]['centroid'])
        # print_time(time_start)
        final_mask_list_ct = Joint_Mask_List_Simple(final_mask_list_ct, now_mask_list_ct, corr_mark)
        # print('centroid -----> ',final_mask_list_ct[0]['centroid'])
        ################################################################################################################
        # Determine approximate time left
        batches_done = i+1
        batches_left = 1 * mask_stack.shape[0] - batches_done
        time_left_seconds = int(batches_left * (time.time() - prev_time))
        time_left = datetime.timedelta(seconds=time_left_seconds)
        prev_time = time.time()
        ################################################################################################################
        if i % 1 == 0:
            time_end = time.time()
            time_cost = time_end - time_start  # datetime.timedelta(seconds= (time_end - time_start))
            print(
                '\r\033[1;33m[MERGE]\033[0m [Patch %d/%d] [Time Cost: %.0d s] [ETA: %s s]     '
                % ( 
                i ,
                mask_stack.shape[0],
                time_cost,
                time_left_seconds
                ), end=' ')
        if (i + 1) %  mask_stack.shape[0] == 0:
            print('\n', end=' ')

    final_mask_list_ct = listAddtrace(final_mask_list_ct, raw_image)
    # ('centroid -----> ',final_mask_list_ct[0]['centroid'])
    return final_mask_list_ct



def clear_up_neuron(whole_mask_list, 
                    raw_image, 
                    quit_round_rate = 0.5,  
                    good_round_rate = 0.8, 
                    good_round_size_rate = 0.4, 
                    corr_mark=0.9):
    save_folder = datetime.datetime.now().strftime("%Y%m%d-%H%M")
    if not os.path.exists(save_folder): 
        os.mkdir(save_folder)

    for ii in range(0,len(whole_mask_list)):
        single_neuron = whole_mask_list[ii]
        position = single_neuron['position']
        mask_j = np.zeros((raw_image.shape[1], raw_image.shape[2]), np.uint8)
        for j in range(0, len(position)):
            mask_j[position[j][0], position[j][1]] = 255
        io.imsave(save_folder+'//0_'+str(ii)+'.tif', mask_j)

    neuron_size = 20
    neuron_area = math.pi*neuron_size*neuron_size/4
    smallest_neuron_area = 50
    rest_rate = 0.5

    clear_neuron_list = []
    for i in range(0, len(whole_mask_list)):
        old_neuron = whole_mask_list[i]
        old_neuron_position = old_neuron['position']

        mask_j = np.zeros((raw_image.shape[1], raw_image.shape[2]), np.uint8)
        for j in range(0, len(old_neuron_position)):
            mask_j[old_neuron_position[j][0], old_neuron_position[j][1]] = 255

        mask_jRGB = cv2.cvtColor(mask_j, cv2.COLOR_GRAY2BGR)
        mask_jgray = cv2.cvtColor(mask_jRGB, cv2.COLOR_BGR2GRAY)  
        ret, binary = cv2.threshold(mask_jgray,100,255,cv2.THRESH_BINARY)    
        contours, hierarchy = cv2.findContours(binary,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
        '''
        for iii in range(0, len(contours)):
            cnt_cnt = contours[iii]
            print('len(contours) -----> ',len(contours),len(cnt_cnt))
        '''
        # if len(contours)==1:
        if len(contours)>0:
            cnt = contours[0]
            area = cv2.contourArea(cnt)
            perimeter = cv2.arcLength(cnt,True)
            if perimeter!=0:
                round_rate = 4*math.pi*area/perimeter/perimeter

                if round_rate>quit_round_rate:
                    if (area<=neuron_area*rest_rate) and (area>smallest_neuron_area):
                        ellipse = cv2.fitEllipse(cnt)
                        (xc,yc),(d1,d2),angle = ellipse
                        size_rate = d2/neuron_size
                        nli_size_rate = size_rate**2+1/(size_rate**2)-1
                        round_size_rate = round_rate/nli_size_rate

                        # if round_rate>=good_round_rate:
                        single_neuron = {}
                        single_neuron['position'] = old_neuron_position
                        clear_neuron_list.append(single_neuron)

                        position = single_neuron['position']
                        mask_j = np.zeros((raw_image.shape[1], raw_image.shape[2]), np.uint8)
                        for j in range(0, len(position)):
                            mask_j[position[j][0], position[j][1]] = 255
                        io.imsave(save_folder+'//'+str(i)+'_'+str(area)+'_1.tif', mask_j)

                    if area>neuron_area*rest_rate:
                        ellipse = cv2.fitEllipse(cnt)
                        (xc,yc),(d1,d2),angle = ellipse
                        size_rate = d2/neuron_size
                        nli_size_rate = size_rate**2+1/(size_rate**2)-1
                        round_size_rate = round_rate/nli_size_rate

                        # if round_size_rate>=good_round_size_rate:
                        if round_rate>=good_round_rate:
                            single_neuron = {}
                            single_neuron['position'] = old_neuron_position
                            clear_neuron_list.append(single_neuron)

                            position = single_neuron['position']
                            mask_j = np.zeros((raw_image.shape[1], raw_image.shape[2]), np.uint8)
                            for j in range(0, len(position)):
                                mask_j[position[j][0], position[j][1]] = 255
                            io.imsave(save_folder+'//'+str(i)+'_'+str(area)+'_'+str(round_rate)+'_2.tif', mask_j)

                        # if round_size_rate<good_round_size_rate:
                        if round_rate<good_round_rate:
                            single_neuron = {}
                            single_neuron['position'] = old_neuron_position

                            Split_Neuron_list = Split_Neuron(single_neuron, raw_image, 0.6, 0.8)
                            print('Split_Neuron_list -----> ',len(Split_Neuron_list))
                            clear_neuron_list.extend(Split_Neuron_list)

                            for ii in range(0,len(Split_Neuron_list)):
                                single_neuron = Split_Neuron_list[ii]
                                position = single_neuron['position']
                                mask_j = np.zeros((raw_image.shape[1], raw_image.shape[2]), np.uint8)
                                for j in range(0, len(position)):
                                    mask_j[position[j][0], position[j][1]] = 255
                                io.imsave(save_folder+'//'+str(i)+'_'+str(ii)+'_'+str(area)+'_1.tif', mask_j)

    clear_neuron_list = listAddtrace(clear_neuron_list, raw_image)
    final_neuron_list = Joint_Mask_List_Simple(clear_neuron_list, [], corr_mark)
    return final_neuron_list
    
