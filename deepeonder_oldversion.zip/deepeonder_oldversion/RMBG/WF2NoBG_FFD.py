import os
import torch
import torch.nn as nn
from torch.autograd import Variable
from torch.utils.data import DataLoader
import argparse
import time
import datetime
from RMBG.network import Network_3D_Unet
import numpy as np
from RMBG.utils import save_yaml, read_yaml
from RMBG.data_process import test_preprocess_lessMemoryNoTail_chooseOne, testset, multibatch_test_save, singlebatch_test_save
from skimage import io
from RMBG.utils import FFDrealign4, inv_FFDrealign4
#############################################################################################################################################
def wf2nobg_ffd(RMBG_GPU='0', 
                RMBG_batch_size=1, 
                RMBG_img_w=256, 
                RMBG_img_h=256, 
                RMBG_img_s=256, 
                RMBG_gap_w=224, 
                RMBG_gap_h=224, 
                RMBG_gap_s=224, 
                RMBG_normalize_factor=1,
                RMBG_output_dir='', 
                RMBG_datasets_path='', 
                RMBG_pth_path='', 
                RMBG_datasets_folder='', 
                RMBG_model_folder='', 
                RMBG_model_name='', 
                RMBG_test_datasize=10000, 
                RMBG_fmap=32):
    #############################################################################################################################################
    parser = argparse.ArgumentParser()
    parser.add_argument('--GPU', type=str, default='0,1', help="the index of GPU you will use for computation")

    parser.add_argument('--batch_size', type=int, default=2, help="batch size")
    parser.add_argument('--img_w', type=int, default=150, help="the width of image sequence")
    parser.add_argument('--img_h', type=int, default=150, help="the height of image sequence")
    parser.add_argument('--img_s', type=int, default=150, help="the slices of image sequence")
    
    parser.add_argument('--gap_w', type=int, default=60, help='the width of image gap')
    parser.add_argument('--gap_h', type=int, default=60, help='the height of image gap')
    parser.add_argument('--gap_s', type=int, default=60, help='the slices of image gap')

    parser.add_argument('--normalize_factor', type=int, default=1, help='normalize factor')
    parser.add_argument('--fmap', type=int, default=16, help='number of feature maps')

    parser.add_argument('--output_dir', type=str, default='./results', help="output directory")
    parser.add_argument('--datasets_path', type=str, default='datasets', help="dataset root path")
    parser.add_argument('--pth_path', type=str, default='pth', help="pth file root path")
    parser.add_argument('--datasets_folder', type=str, default='test', help="A folder containing files to be tested")
    parser.add_argument('--RMBG_model_folder', type=str, default='train_20210401_1712', help='A folder containing models to be tested')
    parser.add_argument('--RMBG_model_name', type=str, default='train_20210401_1712', help='A folder containing models to be tested')
    parser.add_argument('--test_datasize', type=int, default=300, help='dataset size to be tested')
    opt = parser.parse_args()
    #############################################################################################################################################
    opt.GPU = RMBG_GPU
    opt.batch_size = RMBG_batch_size
    opt.img_w = RMBG_img_w
    opt.img_h = RMBG_img_h
    opt.img_s = RMBG_img_s

    opt.gap_w = RMBG_gap_w
    opt.gap_h = RMBG_gap_h
    opt.gap_s = RMBG_gap_s

    opt.normalize_factor = RMBG_normalize_factor
    opt.fmap = RMBG_fmap

    opt.output_dir = RMBG_output_dir
    opt.datasets_path = RMBG_datasets_path
    opt.pth_path = RMBG_pth_path
    opt.datasets_folder = RMBG_datasets_folder
    opt.RMBG_model_folder = RMBG_model_folder
    opt.RMBG_model_name = RMBG_model_name
    opt.test_datasize = RMBG_test_datasize
    #############################################################################################################################################
    os.environ["CUDA_VISIBLE_DEVICES"] = str(opt.GPU)
    # print(pth_path)
    model_path = opt.pth_path + '//' + RMBG_model_folder
    # print(model_path)
    # get stacks for processing
    im_folder = opt.datasets_path + '//' + opt.datasets_folder
    # print('im_folder ------> ',im_folder)
    img_list = list(os.walk(im_folder, topdown=False))[-1][-1]
    img_list.sort()

    if not os.path.exists(opt.output_dir):
        os.mkdir(opt.output_dir)
    current_time = '' #datetime.datetime.now().strftime("%Y%m%d%H%M")
    output_path1 = opt.output_dir + '//' +  current_time + RMBG_model_folder + '_' + RMBG_model_name

    if not os.path.exists(output_path1):
        os.mkdir(output_path1)

    ##############################################################################################################################################################
    # network architecture and GPU access
    denoise_generator = Network_3D_Unet(in_channels=4,
                                        out_channels=4,
                                        f_maps=opt.fmap,
                                        final_sigmoid=True)
    if torch.cuda.is_available():
        denoise_generator = denoise_generator.cuda()
    cuda = True if torch.cuda.is_available() else False
    Tensor = torch.cuda.FloatTensor if cuda else torch.FloatTensor
    ##############################################################################################################################################################

    # Start processing
    if True:
        if True:
            pth_name = RMBG_model_name+'.pth'
            output_path = output_path1
            if not os.path.exists(output_path):
                os.mkdir(output_path)

            # load model
            model_name = opt.pth_path + '//' + RMBG_model_folder + '//' + pth_name
            if isinstance(denoise_generator, nn.DataParallel):
                denoise_generator.module.load_state_dict(torch.load(model_name))  # parallel
                denoise_generator.eval()
            else:
                denoise_generator.load_state_dict(torch.load(model_name))  # not parallel
                denoise_generator.eval()
            denoise_generator.cuda()

            # test all stacks
            for N in range(len(img_list)):
                name_list, noise_img, coordinate_list = test_preprocess_lessMemoryNoTail_chooseOne(opt, N)
                #print(len(name_list))
                prev_time = time.time()
                time_start = time.time()
                denoise_img = np.zeros(noise_img.shape)
                input_img = np.zeros(noise_img.shape)

                test_data = testset(name_list, coordinate_list, noise_img)
                testloader = DataLoader(test_data, batch_size=opt.batch_size, shuffle=False, num_workers=4)
                for iteration, (noise_patch,single_coordinate) in enumerate(testloader):
                    noise_patch=noise_patch.cuda().float()

                    real_A = FFDrealign4(noise_patch)
                    real_A = Variable(real_A)
                    
                    fake_B = denoise_generator(real_A)
                    ################################################################################################################
                    # Determine approximate time left
                    batches_done = iteration
                    batches_left = 1 * len(testloader) - batches_done
                    time_left_seconds = int(batches_left * (time.time() - prev_time))
                    time_left = datetime.timedelta(seconds=time_left_seconds)
                    prev_time = time.time()
                    ################################################################################################################
                    if iteration % 1 == 0:
                        time_end = time.time()
                        time_cost = time_end - time_start  # datetime.timedelta(seconds= (time_end - time_start))
                        print(
                            '\r[RMBG] [Stack %d/%d, %s] [Patch %d/%d] [Time Cost: %.0d s] [ETA: %s s]     '
                            % ( N + 1,
                                len(img_list),
                                img_list[N],
                                iteration + 1,
                                len(testloader),
                                time_cost,
                                time_left_seconds
                            ), end=' ')

                    if (iteration + 1) % len(testloader) == 0:
                        print('\n', end=' ')
                    ################################################################################################################
                    fake_B_realign = inv_FFDrealign4(fake_B)
                    output_image = np.squeeze(fake_B_realign.cpu().detach().numpy())
                    real_A_realign = inv_FFDrealign4(real_A)
                    raw_image = np.squeeze(real_A_realign.cpu().detach().numpy())
                    if(output_image.ndim==3):
                        turn=1
                    else:
                        turn=output_image.shape[0]
                    #print(turn)
                    if(turn>1):
                        for id in range(turn):
                            #print('shape of output_image -----> ',output_image.shape)
                            aaaa,bbbb,stack_start_w,stack_end_w,stack_start_h,stack_end_h,stack_start_s,stack_end_s=multibatch_test_save(single_coordinate,id,output_image,raw_image)
                            denoise_img[stack_start_s:stack_end_s, stack_start_h:stack_end_h, stack_start_w:stack_end_w] \
                            = aaaa 
                            input_img[stack_start_s:stack_end_s, stack_start_h:stack_end_h, stack_start_w:stack_end_w] \
                            = bbbb
                    else:
                        aaaa, bbbb, stack_start_w, stack_end_w, stack_start_h, stack_end_h, stack_start_s, stack_end_s = singlebatch_test_save(
                            single_coordinate, output_image, raw_image)
                        denoise_img[stack_start_s:stack_end_s, stack_start_h:stack_end_h, stack_start_w:stack_end_w] \
                            = aaaa 
                        input_img[stack_start_s:stack_end_s, stack_start_h:stack_end_h, stack_start_w:stack_end_w] \
                            = bbbb

                # del noise_img
                output_img = denoise_img.squeeze().astype(np.float32) * opt.normalize_factor
                del denoise_img
                # print(np.min(output_img),' -----> ',np.max(output_img))
                output_img = np.clip(output_img, 0, 65535).astype('uint16')
                # output_img = output_img - output_img.min()
                # output_img = output_img.astype('uint16')

                result_name = output_path + '//' + img_list[N].replace('.tiff', '') + '_' + pth_name.replace('.pth', '') + '_output.tif'
                io.imsave(result_name, output_img, check_contrast=False)
    return output_img

